package com.cg.FirstSel;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\gkhkh\\FirstSel\\feature\\wiki.feature", glue= {"stepDefinition"})
public class Myrunner {

}
