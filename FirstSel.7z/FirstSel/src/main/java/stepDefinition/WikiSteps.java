package stepDefinition;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WikiSteps {
	
	
	
	WebDriver driver;
	
	@Given("^user is on the home page$")
	public void user_is_on_the_home_page() {
		System.setProperty("webdriver.chrome.driver", "D://Users//stupakul//Downloads/chromedriver.exe");
		
		driver= new ChromeDriver();
		
		driver.get("http:www.wikipedia.com/");
	}

	@When("^user enters a search query$")
	public void user_enters_a_search_query() {
		
		driver.findElement(By.xpath("//input[@id='searchInput']")).sendKeys("india");
	}

	@When("^clicks on Search button$")
	public void clicks_on_Search_button() {
		
		driver.findElement(By.xpath("//i[@class='sprite svg-search-icon']")).click();
		}

	@Then("^display search query page$")
	public void display_search_query_page() {
		if(driver.getTitle().equals("India - Wikipedia")) {
			System.out.println("title is matched");
		}
	}


}
